# Figure caption and interpretation

## Suggested caption

**Presidential attention to energy in State of the Union addresses, 1946–2020.** The blue line shows the share of each address devoted to energy, measured as the fraction of words contained in sentence/clause units classified as substantively about energy. The strongest increases occur during the energy crises of the 1970s and around the second oil shock, with smaller periods of elevated attention in the late 2000s and early 2010s.

The background curves are **contextual sanity checks, not inputs to the measure**. Real crude-oil prices show how expensive oil was after adjusting for general U.S. inflation; oil-price inflation captures sudden year-to-year changes in oil prices; and U.S. CPI inflation shows broader economy-wide price pressure. Each contextual series is independently rescaled to 0–1 so that their timing can be compared on the same plot. The comparison suggests that the text-based measure is responding to historically recognizable periods of energy-market stress, while also showing that presidential attention is not simply a mechanical reflection of oil prices or general inflation.

## How the blue series was built

For each of the 75 supplied State of the Union documents, the text was split into sentence/clause units. Units were classified as energy-related when they substantively discussed energy production, supply, distribution, consumption, prices, security, conservation/efficiency, or transition. Civilian nuclear power was included, while nuclear-weapons discussion, metaphorical uses of “energy,” and unrelated conservation/environmental language were excluded. The annual estimate is the number of words in energy-coded units divided by the total number of words in that year's document. No smoothing is applied to the blue series.

## External data used only for the figure

- U.S. crude-oil first-purchase price: U.S. Energy Information Administration (EIA), annual dollars per barrel.
- U.S. CPI-U annual average and annual inflation: U.S. Bureau of Labor Statistics (BLS).
- Real oil price: nominal oil price multiplied by the ratio of the 2020 CPI-U annual average to that year's CPI-U annual average.
- Oil-price inflation: annual percentage change in the nominal oil-price series.
- The contextual curves are shown as centered 3-year averages and then independently normalized to 0–1 for readability. These transformations do **not** affect `results.csv`.

## Interpretation in one sentence

The main result is that U.S. presidents devote substantially more of the State of the Union to energy during major episodes of energy-market disruption, especially in the 1970s, but the imperfect alignment with oil prices and general inflation indicates that the measure captures political attention rather than merely reproducing an economic price series.
