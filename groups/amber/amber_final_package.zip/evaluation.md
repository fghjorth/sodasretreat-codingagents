# Amber: Evaluation of the Coding Agent

## Advantages

The coding agent made it possible to inspect all 75 documents quickly, identify historically changing terminology, implement reproducible preprocessing and coding rules, and compare several measurement strategies within a short session. It was especially useful for finding technical problems that are easy to miss manually, such as very long semicolon-separated policy lists, inconsistent document lengths, ambiguous uses of *nuclear*, *energy*, *conservation*, and *fuel*, and malformed contextual matches. It also made robustness checks and final format validation inexpensive.

A second advantage was rapid iteration between substantive reasoning and implementation. We could inspect examples, convert a conceptual distinction (for example civilian nuclear power versus nuclear weapons) into an explicit rule, rerun all 75 years, and see whether alternative methods produced the same broad temporal pattern.

## Disadvantages

The agent can make methodological choices look more objective than they are. Decisions about what counts as energy are construct-validity decisions, not coding details, and an agent-generated dictionary or classifier can silently encode questionable boundaries. More flexible methods can also produce convincing but wrong results: the TF–IDF classifier, for example, sometimes treated rhetorical phrases such as “energy and drive” and atomic/nuclear institutional or weapons language as energy-policy attention.

The workflow is also sensitive to implementation details. An initially reasonable sentence-based method overcounted a long 1991 multi-topic policy list because one energy clause occurred inside a single grammatical sentence. Without inspection, that error could have survived into the final series. Agent speed therefore increases the amount that can be tried, but it can also increase the number of hidden analytical choices.

## Oversight and trust

Human judgment is required most strongly for the construct definition: whether oil geopolitics, fuel taxes, civilian atomic power, environmental policy, or generic conservation belong in the concept. Humans should also inspect ambiguous examples, unusual peaks/zeros, and any classification method that extrapolates beyond explicit rules.

We would not trust an opaque per-speech percentage, an unsupervised topic label, or a weakly supervised/LLM classification series as a final research measure without manual auditing. We would trust the agent more for deterministic preprocessing, counting, applying an agreed rule consistently, running robustness analyses, and checking file/schema requirements, provided the code and consequential rules remain inspectable.

## Overall assessment

For a similar research task, we would use a coding agent again for corpus inspection, preprocessing, implementation of transparent measures, generation of alternative specifications, diagnostics, reproducibility checks, and documentation. We would not delegate the substantive definition of the construct, the final judgment on ambiguous categories, or interpretation of historical trends entirely to the agent. The most productive division of labor is for humans to define and audit the measurement concept and for the agent to implement it consistently and expose sensitivity to alternative reasonable choices.
