# Amber: Analytical Approach

## Definition

We defined **attention to energy** as substantive discussion of the production, supply, transformation, distribution, consumption, price, conservation/efficiency, security, or transition of energy. This includes oil and petroleum, gasoline, natural gas, coal, electricity and grids, hydroelectricity, nuclear power, solar, wind, renewable and alternative fuels, energy efficiency, and energy-related infrastructure. We included geopolitical discussion when an energy resource itself was substantively at issue (for example oil supply, embargoes, dependence, or control of oil resources).

We excluded metaphorical uses of *energy* (for example “energy and drive”), general conservation of land/forests/wildlife, generic climate/environment discussion without an energy connection, and nuclear weapons, deterrence, proliferation, testing, or arms-control discussion. Early references to atomic energy were counted only when they concerned civilian/industrial/peaceful energy use or power development rather than atomic diplomacy or weapons control.

## Measurement

We used `corpus.csv` as the only speech corpus. The 75 supplied documents (1946–2020) and their text were left unchanged.

The primary method was a **high-precision contextual clause classifier**. Text was separated at paragraph breaks and then into sentence/clause units, splitting at sentence endings and semicolons. The semicolon split matters because State of the Union addresses often contain long multi-topic policy lists; counting an entire list as energy because one item mentions energy would overstate attention. Word/number tokens were counted with the same tokenizer in every year.

A unit was coded as energy when it contained a high-precision energy-system expression (for example oil, natural gas, gasoline, electricity, coal, nuclear power, energy policy, energy conservation, renewable energy, solar power, wind power, biofuels, power grids). Ambiguous terms were handled contextually. Nuclear/atomic terms associated with weapons were excluded; general conservation was excluded unless explicitly linked to energy; metaphorical uses of *energy* and *fuel* were excluded. A small second pass recovered ambiguous technology/infrastructure terms such as pipelines, batteries, hydrogen, drilling, or nuclear facilities only when they occurred directly next to an already-coded energy clause in the same paragraph.

For year \(y\), the submitted estimate is

\[
A_y = \frac{\text{word tokens in clauses coded as energy}}{\text{word tokens in the full document}}.
\]

Thus the output estimates an unsmoothed share of each year's document devoted to energy and is directly comparable across years despite very different document lengths.

We also ran two robustness approaches before choosing the primary measure:

1. **Local-window measure:** the union of each coded energy clause plus a 20-word buffer on either side, divided by document words. This tests sensitivity to clause boundaries but predictably produces larger estimates.
2. **Weakly supervised TF–IDF classifier:** word and character n-gram TF–IDF features with logistic regression, trained from the high-precision energy clauses against a deterministic sample of non-energy clauses, using a conservative 0.85 probability threshold. This can recover indirect language but also extrapolates errors.

The annual patterns were very similar: Pearson correlation was about 0.992 between the primary and local-window series and 0.984 between the primary and TF–IDF series. We submitted the contextual clause measure because it had the clearest substantive interpretation and the fewest obvious false positives.

## Agent workflow

The group asked the coding agent to inspect the supplied corpus, compare three defensible approaches, perform the complete analysis within the retreat time constraint, and generate the required files. The agent inspected corpus structure and terminology, implemented all three estimators, compared their results, and audited ambiguous classifications. Consequential coding rules were made explicit rather than using the agent to assign an unexplained percentage to each speech.

Group direction determined the overall objective and the decision to compare three serious methods. Methodological revisions during the analysis were driven by observed semantic/segmentation errors (for example nuclear-weapons false positives and multi-topic semicolon lists), not by trying to force the time series to match an expected historical shape.

## Checks

We spot-checked roughly 80 ambiguous units spread across the corpus, with particular attention to *energy*, *atomic/nuclear*, *conservation*, *fuel*, *wind*, *pipeline*, and *drilling*, and inspected several high- and low-attention years. This exposed false positives from nuclear weapons, metaphorical language, generic conservation, and long policy lists and led to explicit exclusion/segmentation rules. The two alternative estimators were also used as robustness checks.

## Important choices

The most consequential choices were: using word share rather than raw counts; coding sentence/clause units rather than whole paragraphs; splitting semicolon-separated lists; favoring precision over aggressive recovery of implicit references; including energy-security and oil-geopolitics discussion; counting civilian nuclear power but excluding nuclear weapons/arms control; and requiring an explicit energy connection for conservation, climate, and ambiguous technologies.

## Limitations

This remains a rule-based measurement, not a hand-coded gold standard. It can miss indirect discussion that uses no recognizable energy vocabulary, and whole-clause coding can still overcount or undercount mixed clauses. Historical terminology changes over 75 years, especially around atomic/nuclear power. The limited contextual recovery rule is deliberately conservative and may miss some valid continuations. The TF–IDF robustness model showed that automated semantic expansion can introduce plausible-looking but substantively wrong classifications, so it was not used as the final estimator. Finally, the fixed corpus mixes spoken and written documents of very different lengths; normalization handles length but cannot remove all differences in rhetorical/document style.

## External sanity-check figure

For interpretation only, we compared the submitted energy-attention series with historical U.S. crude-oil prices and U.S. CPI inflation. We constructed a CPI-deflated real oil-price series (2020 dollars) and annual oil-price inflation, displayed the external curves as centered 3-year averages, and independently normalized them to 0–1 for visual comparison. These external data were not used to define, train, tune, or modify the speech-based estimator; they are post-estimation sanity checks only.
